# Создадим специальную функцию для перекодировки
funcImtText <- function(AgeYears, IMT) {
  ifelse(AgeYears >= 18 & IMT <= 16, 'Выраженный дефицит массы тела',
         ifelse(AgeYears >= 18 & IMT > 16 & IMT <= 18.5, 'Недостаточная (дефицит) масса тела',
                ifelse(AgeYears >= 18 & IMT > 18.5 & IMT <= 25 , 'Норма',
                       ifelse(AgeYears >= 18 & IMT > 25 & IMT <= 30, 'Избыточная масса тела',
                              ifelse(AgeYears >= 18 & IMT > 30 & IMT <= 35, 'Ожирение первой степени',
                                     ifelse(AgeYears >= 18 & IMT > 35 & IMT <= 40, 'Ожирение второй степени',
                                            ifelse(AgeYears >= 18 & IMT > 40, 'Ожирение третьей степени',
                                                   "Не применимо")))))))
}