#### Подготовка данных ####

##### Пример чтения данных из Excel и Csv #####

library(readxl)
df_excel <- read_excel("files/Book1.xlsx")
head(df_excel)

library(openxlsx)
data <- read.xlsx("files/Book1.xlsx", sheet = "Sheet1")

library(readr)
df_csv <- read_csv("files/Book1.csv")
head(df_csv)

#### Переименование столбцов ####

df <- read_csv("files/crf.csv")
# Показать имена столбцов
colnames(df)
# Переименование всех столбцов
colnames(df) <- c("case_history", "sex", 
                  "date_birth", "data_start", 
                  "height", "weight", "is_complete", 
                  "material", "unique_id")
# Переименование одного столбца
names(df)[9] <- "id"
colnames(df)

#### Переименование столбцов с janitor ####

df = data.frame(a = NA, b = NA, c = NA, d = NA)
names(df) <- c("ФИО", "Дом.адреc", "Готовность (%)", "Номер телефона") # Назначим имена столбцов

# Ручная очистка имен
library(stringi)
names(df) <- stri_trans_general(names(df), "russian-latin/bgn") # транслитерируем
names(df) <- tolower(names(df))                        # приводим в нижний регистр
names(df) <- gsub(" ", "_", names(df))                 # заменяем пробелы на подчеркивания
names(df) <- gsub("[^[:alnum:]_]", "", names(df))      # удаляем все специальные символы
names(df)

# Очистка с janitor
library(janitor)
names(df) <- c("ФИО", "Дом.адреc", "Готовность (%)", "Номер телефона") # Назначим имена столбцов
df <- clean_names(df)
names(df)

# Точечная замена с dplyr
library(dplyr)
df <- rename(df, "address" = "dom_adrec", "name" = "fio")
names(df)

#### Названия строк в столбцы ####

library(readxl)
df <- read_excel("files/table_header.xlsx")
df


# Попробуем найти настоящие заголовки
library(janitor)
find_header(df)

# Покажем, где настоящие заголовки столбцов
df <- row_to_names(df, row_number = 1)
df

#### Удаление пустых строк и столбцов ####

df <- data.frame(
  ID = c(1, 2, NA, 4, 5),
  Name = c("John", "Jane", NA, NA,NA),
  Age = c(25, 30, NA, NA, NA),
  Empty_Col = c(NA, NA, NA, NA, NA)
)
df

# Удаляем пустые строки
df <- df[rowSums(is.na(df)) != ncol(df), ]
# Удаляем пустые столбцы
df <- df[, colSums(is.na(df)) != nrow(df)]
# Выводим результат
df

df <- data.frame(
  ID = c(1, 2, NA, 4, 5),
  Name = c("John", "Jane", NA, NA,NA),
  Age = c(25, 30, NA, NA, NA),
  Empty_Col = c(NA, NA, NA, NA, NA)
)
df

# Удаляем пустые столбцы и строки с janitor

library(janitor)
df <- remove_empty(df, which = c("cols", "rows"))
# Выводим результат
df

#### Поиск дублирующихся строк ####

# Пример набора данных с дублями строк
df <- data.frame(
  ID = c(1, 2, 3, 3, 4, 5, 5),
  Name = c("John", "Jane", "Doe", "Doe", "Alice", "Bob", "Bob"),
  Age = c(25, 30, 22, 22, 40, 35, 35)
)
df

# Поиск дублирующихся строк
library(janitor)
dupes <- get_dupes(df)
dupes

# Схлопывание дублирующихся строк
library(dplyr)
df <- distinct(df)
df

#### Поиск и замена пропущенных данных ####

df <- data.frame(
  id = c(1,2,3,4),
  name = c("AAA", "BBB", "BBB", "CCC"),
  sex = c("М","Ж",NA, "М"),
  age = c(18, 20, NA, 34),
  temp = c(37, NA, 36.9, 37.2)
)
df

# Поиск пропусков в столбце
is.na(df$sex) 
# Замена пропущенных значений для столбца
df[is.na(df$sex), ]$sex <- ""
df

# Замена пропущенных значений c dplyr
library(dplyr)
df$temp <- coalesce(df$temp, 36.6)
df

#### Замена пропущенных данных с tidyr ####

df <- data.frame(
  id = c(1,2,3,4),
  name = c("AAA", "BBB", "BBB", "CCC"),
  sex = c("М","Ж",NA, "М"),
  age = c(18, 20, NA, 34),
  temp = c(37, NA, 36.9, 37.2)
)
df

library(tidyr)
# Замена пропусков на значения по умолчанию
df <- replace_na(df, list(sex = "-", 
                          age = -1, 
                          temp = 36.6))
df


df <- data.frame(
  id = c(1,2,3,4),
  name = c("AAA", "BBB", "BBB", "CCC"),
  sex = c("М","Ж",NA, "М"),
  age = c(18, 20, NA, 34),
  temp = c(37, NA, 36.9, 37.2)
)

library(tidyr)
# Замена с использованием существующих значений
df <- fill(df, sex, .direction = "down")
df <- fill(df, age, .direction = "down")
df <- fill(df, temp, .direction = "up")
df

#### Удаление строк с пропусками ####

df <- data.frame(
  id = c(1,2,3,4),
  name = c("AAA", "BBB", "BBB", "CCC"),
  sex = c("М","Ж",NA, "М"),
  age = c(18, 20, NA, 34),
  temp = c(37, NA, 36.9, 37.2)
)
df

library(dplyr)
# Удаление строк с пропусками в столбце
df <- drop_na(df, temp)
df
# Удаление всех строк с пропусками
df <- drop_na(df)
df

#### Корректное чтение дат ####

df <- tibble(
  date = c("11.03.2025", 
           "12.03.2025", 
           "13.14.2025"),
  datetime = c("11.03.2025 11:45", 
               "12.03.2025 10:05", 
               "13.12.2025 16:76")
)
df

# Преобразование в дату
df$date_new <- as.Date(df$date, format = "%d.%m.%Y")
# Преобразование в дату и время
df$datetime_new <- as.POSIXct(df$datetime, 
                              format = "%d.%m.%Y %H:%M")
df

#### Корректное чтение с `parsedate` ####

df <- tibble(
  id = c(1,2,3,4),
  date = c("april 15 2025", 
           "15/04/2025", 
           "04/15/2025", 
           "2025-04-15")
)
df

library(parsedate)
df$date_new <- parse_date(df$date)
df

parse_date(c("04/04/2025", "12/03/2025", "03/12/2025"))

#### Корректное чтение дат с `lubridate` ####

df <- tibble(
  id = c(1,2,3),
  date = c("04/04/2025", 
           "12/03/2025", 
           "03/12/2025")
)
df

library(lubridate)
df$date_1 <- dmy(df$date) # Если в начале стоит день
df$date_2 <- mdy(df$date) # Если в начале стоит месяц
df

ymd("200121")
mdy("January 21st, 2020")
dmy("21-Jan-2020")
ymd_hms("2021-12-14 00:31:51")

#### Корректное чтение дат с `janitor` ####

df <- tibble(
  id = c(1,2,3),
  date = c("2020-02-29", 
           "40000.1",
           "42232")
)
df

# Конвертация даты и времени из Excel
excel_numeric_to_date(c(42232, 42232.521))
excel_numeric_to_date(c(42232, 42232.521), 
                      include_time = TRUE)

# Универсальная конвертация
df$date_new <- convert_to_date(df$date)
# Можно указать, как обрабатывать строковые даты
df$datetime_new <- convert_to_datetime(df$date, 
                                       character_fun = lubridate::ymd)
df

#### Расчет длительности ####

df <- df[,c("date_new")]
colnames(df) <- c("date")
df

# День назад
df$day_before <- df$date - days(1)
# Возраст на сегодня
library(lubridate)
df$age <- interval(df$date, now()) / years(1)
df$age_int <- interval(df$date, now()) %/% years(1)
df$age_mon <- interval(df$date, now()) %/% months(1)
df

#### Корректное чтение чисел с `readr` ####

v <- c("$1,123,456.00", "500 $", "95%")
# Стандартная функция требует только цифры
as.double(v)
# Позволяет преобразовать число с символами
parse_number(v)

# Символы-разделители могут отличаться
v <- c("123.456,00", "678.900,50")
parse_number(v)
# Можно задать настройки локали
loc <- locale("es", 
              decimal_mark = ",", 
              grouping_mark = ".")
parse_number(v, locale = loc)

# Интерпретация значений/пропусков
x <- c("1", "2", "3", "-", "6", "-1", "7")
# При обычном парсинге будет предупреждение
parse_double(x)
# Чтобы скрыть предупреждение нужно задать 
# какие значения считать NA
parse_double(x, na = c("-", ""))
# Можно задать и числовые значения-заглушки
parse_double(x, na = c("-", "", "-1"))

#### Преобразование единиц измерения ####

library(readxl)
df <- read_excel("files/table_header.xlsx")
df <- row_to_names(df, row_number = 1)
df$Рост <- parse_number(df$Рост)
df$Вес <- parse_number(df$Вес)
df

# Приведем рост в сантиметры с помощью ifelse(условие, истина, ложь)
df$height_cm <- ifelse(df$Рост < 10,  # Логическое условие
                       df$Рост * 100, # Значение, если ИСТИНА
                       df$Рост        # Значение, если ЛОЖЬ
)
df

# Можно использовать любые функции и формулы
df$height_m <- df$height_cm / 100
df

#### Округление ####

df <- data.frame(
  val = c(1, 1.49, 1.5, 2.5, 2.55, 3.14159)
)
df

# Стандартные функции округления
# до целой части
df$round <- round(df$val)
# до второго знака после запятой
df$round_d <- round(df$val, 2)
# в большую сторону
df$ceiling <- ceiling(df$val)
# в меньшую сторону
df$floor <- floor(df$val)  
df

# Округление с janitor
library(janitor)
# до целой части
df$half_up <- round_half_up(df$val)
# до второго знака после запятой
df$half_up_2 <- round_half_up(df$val, 2)
df

#### Категоризация числовых данных ####

df <- tibble(
  name = c("ААА", "БББ", "ВВВ", "ГГГ"),
  sex = c("М","Ж","М", "Ж"),
  imt = c(12, 21,28,33)
)
df

# Категоризация с dplyr::case_when
library(dplyr)
df <- mutate(df, imt_text = case_when(
  imt <= 16 ~ 'Выраженный дефицит массы тела',
  imt > 16 & imt <= 18.5 ~ 'Недостаточная масса тела',
  imt > 18.5 & imt <= 25 ~ 'Норма',
  imt > 25 & imt <= 30 ~ 'Избыточная масса тела',
  imt > 30 & imt <= 35 ~ 'Ожирение первой степени',
  imt > 35 & imt <= 40 ~ 'Ожирение второй степени',
  imt > 40 ~ 'Ожирение третьей степени',
  TRUE ~ "Не применимо"))
df

#### Пробелы, регистры, выравнивание ####

df <- tibble(
  t1 = c("  пробелы слева", "пробелы справа  ", "  пробелы с двух сторон  "),
  t2 = c("один пробел", "два  пробела", "три   пробела"),
  t3 = c("1A", "02Б", "003В"),
)
df

library(stringr)
# Удаление висячих пробелов
df$t1 <- str_trim(df$t1)
# Удаление повторяющихся пробелов внутри
df$t2 <- str_squish(df$t2)
# Дополнение строки символами
df$t3 <- str_pad(df$t3, 
                 width = 6,     # до скольки дополняем
                 side = "left", # где дополняем
                 pad = "0"      # чем дополняем
)
df

library(stringr)
# Верхний регистр
str_to_upper(df$t1) 
# Нижний регистр
str_to_lower(df$t1) 
# Заголовочный регистр
str_to_title(df$t1) 
# Регистр предложения
str_to_sentence(df$t1)

#### Поиск c grep ####

df <- tibble(
  sex = c("Ж","жен","женский","Женский","М","муж","мужской"),
  type = c("One", NA, "Two", "Cat 3", "3 3", "Cat 33", NA),
)
df

# Проверка значений
library(janitor)
tabyl(df$sex)

# Функции для поиска `grep()` и `grepl()`
# grep выдает индексы строк
grep("муж", df$sex)   
# grepl выдает логический вектор
grepl("муж",  df$sex) 
# grep позволяет выводить значения
grep("муж", df$sex, value = TRUE) 

# Для сложных условий можно использовать 
# регулярные выражения

# где встречается буква ж
grep("ж",  df$sex, value = TRUE)
# где слово начинается с буквы ж
grep("^ж", df$sex, value = TRUE) 

#### Замена c grepl ####

df <- tibble(
  sex = c("Ж","жен","женский","Женский","М","муж","мужской"),
  type = c("One", NA, "Two", "Cat 3", "3 3", "Cat 33", NA),
)
df

# Заменим все, что начинается на м на мужской
df[grepl("^м", df$sex, ignore.case = TRUE),]$sex <- "Мужской"
# Заменим все, что начинается на ж на женский
df[grepl("^ж", df$sex, ignore.case = TRUE),]$sex <- "Женский"
df

# Проверим значения
tabyl(df$sex)

#### Замена с пакетом `stringr` ####

df

str_replace_na(df$type, "None") # Замена NA
str_replace(df$type, "3", "Three") # Замена первого вхождения
str_replace_all(df$type, "3", "Three") # Замена всех вхождений
str_replace_all(df$type, "\\d+", "") # Удалить все цифры

df$type <- str_replace_na(df$type, "None") # Замена NA
df$type <- str_replace(df$type, "3", "Three") # Замена первого вхождения
df$type <- str_replace_all(df$type, "\\d+", "") # Удалить все цифры
df$type <- str_replace_all(df$type, "^Cat", "") # Удалить в начале Cat
df$type <- str_trim(df$type) # Удалить висячие пробелы
df

#### Перекодировка с пакетом `dplyr` ####

df <- tibble(
  city = c("Москва", "Минск", "Астана", "Смоленск", "Брянск", "-", NA)
)
df

library(dplyr)
# Функция recode позволяет перекодировать значения с учетом пропушенных данных
df$country <- recode(df$city,
                     `Минск` = "Беларусь",
                     `Астана` = "Казахстан",
                     .default = "Россия", # Значение по умолчанию
                     .missing = "Нет данных"  # Значения NA
)
df

#### Разделение столбцов с пакетом `stringr` ####

df <- tibble(
  material = c("Кожа и мягкие ткани - Биоптат", 
               "Дыхательная система - Мокрота",
               "Дыхательная система - Кровь", 
               "Пищеварительная система - Фекалии"
  )
)
df

# При разделении столбца получим матрицу
str_split_fixed(df$material, 
                pattern = " - ", # Что считаем разделителем
                n = 2 # Сколько элементов вернуть
)

# Для добавления в таблицу обращаемся к столбцам матрицы
df$loc <- str_split_fixed(df$material, " - ", n = 2)[, 1]
df$mat <- str_split_fixed(df$material, " - ", n = 2)[, 2]
df

#### Объединение столбцов с пакетом `stringr` ####

df[,c("loc", "mat")]

# При объединении столбцов можно важно задать обработку NA 
# и символ, который будет сцеплять столбцы
df$loc_mat <- str_c(
  str_replace_na(df$loc,""), 
  str_replace_na(df$mat,""),
  sep = ": "
)

df[,c("loc", "mat", "loc_mat")]


#### Разделение столбцов с пакетом `tidyr` ####

df <- tibble(
  material = c("Кожа и мягкие ткани - Биоптат", 
               "Дыхательная система - Мокрота",
               "Дыхательная система - Кровь", 
               "Пищеварительная система - Фекалии"
  )
)
df

# При разделении столбца получим таблицу
df <- separate(df,   	# исходная таблица
               material,    # столбец для разделения
               sep = " - ",  # символ - разделитель
               remove = FALSE,  # удалять исходный столбец
               into = c("loc", "mat") # названия столбцов
)

df

#### Объединение столбцов с пакетом `tidyr` ####

df[,c("loc", "mat")]

# Функция объединения
df <- unite(df,   	# исходная таблица
            loc, mat,  # столбцы для объединения
            sep = ": ",  # символ - объединитель
            remove = FALSE,  # удалять исходный столбец
            col = "loc_mat" # название нового столбца
)

df[,c("loc","mat", "loc_mat")]

#### Грамматика манипуляций с данными с использованием пакет dplyr ####

#### Выбор строк и столбцов dplyr ####

library(readr)
library(dplyr)
df <- read_csv("./files/crf.csv")
df <- rename(df,
             "case_history" = "№ истории болезни",
             "date_birth" = "Дата рождения",
             "date_start" = "Дата начала",
             "sex" = "Пол",
             "weight" = "Вес",
             "height" = "Рост",
             "is_completed" = "Завершил исследование",
             "material" = "Материал")
head(select(df, sex, weight, height))

# Отфильтруем нужные строки
data <- filter(df, sex == "Мужской", weight > 70, height > 1.70)
# Выберем нужные столбцы
data <- select(data, sex, weight, height)
head(data)

#### Сортировка dplyr ####

data <- arrange(df,
                desc(is_completed), # сортировка по убыванию
                date_start          # по умолчанию сортировка по возрастанию
)
# Выберем нужные столбцы
data <- select(data, case_history, is_completed, date_start)
head(data)
tail(data)

#### Создание новых столбцов dplyr ####

library(dplyr)
library(lubridate)
data <- mutate(df,
               imt = round(weight / ( height ^ 2),2) ,
               age = interval(dmy(date_birth), date_start) / years(1)              )
data <- select(data, unique_id, weight, height, imt, date_birth, date_start, age, is_completed )
head(data)

#### Изменение порядка столбцов ####

library(dplyr)
# По умолчанию столбцы перемещаются в начало таблицы
data <- relocate(data, unique_id) 
# С помощью дополнительных атрибутов .before и .after можно задавать более точное расположение столбцов
data <- relocate(data, date_birth, .after = age)
data <- relocate(data, age, .before = date_birth)
# Все логические столбцы разместим после идентфиикатора
data <- relocate(data, where(is.logical), .after = unique_id)
head(data)

#### Группировка и агрегация dplyr ####

data_grouped <- group_by(data, is_completed)
# Посчитаем агрегирующие функции для возраста
data_summary <- summarize(data_grouped,
                          min_age = min(age, na.rm = TRUE),
                          avg_age = mean(age, na.rm = TRUE),
                          max_age = max(age, na.rm = TRUE))
data_summary

##### Конвейер обработки (пайплайн) #####

# Оператор пайп %>% позволяет записать несколько операций
source("_functions.R")
data <- read_csv("files/crf.csv")
data <- rename(data, 
               "date_birth" = "Дата рождения",
               "date_start" = "Дата начала",
               "sex" = "Пол",
               "weight" = "Вес",
               "height" = "Рост",
               "is_completed" = "Завершил исследование")
data <- filter(data, sex == "Мужской")
data <- select(data, weight, height, date_birth, date_start, is_completed)
data <- mutate(data, 
               imt = weight / ( height ^ 2) ,
               age = interval(dmy(date_birth), date_start) / years(1))
data <- mutate(data, imt_group = funcImtText(age, imt))
data <- group_by(data, is_completed, imt_group)
data <- summarize(data, total = n())
data <- arrange(data, is_completed, desc(total), imt_group)

head(data)

# В одну
data <- read_csv("files/crf.csv") %>% 
  rename("date_birth" = "Дата рождения",
         "date_start" = "Дата начала",
         "sex" = "Пол",
         "weight" = "Вес",
         "height" = "Рост",
         "is_completed" = "Завершил исследование") %>% 
  filter(sex == "Мужской") %>% 
  select(weight, height, date_birth, date_start, is_completed) %>% 
  mutate(imt = weight / ( height ^ 2) ,
         age = interval(dmy(date_birth), date_start) / years(1)) %>% 
  mutate(imt_group = funcImtText(age, imt)) %>% 
  group_by(is_completed, imt_group) %>% 
  summarize(total = n()) %>% 
  arrange(is_completed, desc(total), imt_group)

head(data)


#### Работа с таблицами с использованием data.table #### 

data <- read_csv("files/crf.csv")
library(data.table)
dt <- data.table(data)
class(dt)

#### Производительность data.table #### 


# Скачаем и распакуем большой файл для теста
src <- "https://github.com/hadley/mexico-mortality/raw/master/deaths/deaths08.csv.bz2"
download.file(src, "deaths.csv.bz2", quiet = TRUE)
library(R.utils)
bunzip2("deaths.csv.bz2", "deaths.csv", remove = FALSE, skip = TRUE)

# Чтение с помощью стандартных функций
system.time( deaths_base <- read.csv("deaths.csv") )
# Чтение с помощью пакета readr
system.time( deaths_rdr <- read_csv("deaths.csv") )
# Чтение с помощью пакета data.table
system.time( deaths_dt <- fread("deaths.csv") )

nrow(deaths_dt)
class(deaths_dt)

# Создаем объект data.table
data <- read_csv("files/crf.csv")
dt <- data.table(data)
class(dt)
dt <- as.data.table(data)
class(dt)

#### Выбор и создание столбцов datatable ###

# Читаем таблицу
library(data.table)
dt <- fread("files/crf.csv")
# для выбора столбцов используется точка
dt <- dt[, .(`Завершил исследование`, `Пол`, `Рост`, `Вес`, `Дата рождения`, `Дата начала`)]
head(dt)
# Для создания столбца ему нужно присвоить значение
dt <- dt[, `ИМТ`:=  `Вес` / ( `Рост` ^ 2)]

# Если столбцов несколько, сначала указываются имена, а затем им присваиваются значения
dt <- dt[, c("ИМТ", "Возраст") :=  list(
  `Вес`/(`Рост`^ 2), 
  interval(dmy(`Дата рождения`), `Дата начала`) / years(1))
]

# Можно комбинировать выбор столбцов и создание новых в одной операции
dt <- dt[, .(`Завершил исследование`, `Пол`, `Рост`, `Вес`, `Возраст`, 
             `ИМТ` = `Вес` / ( `Рост` ^ 2))]
dt

#### Переименование datatable ####

# На самом деле операции переименования в пакете data.table нет, 
# но можно присвоить значения существующих столбцов новым и оставить их в наборе данных.
dt <- dt[, list("is_completed" = `Завершил исследование`,
                "height" = `Рост`,
                "weight" = `Вес`,
                "age" = `Возраст`,
                "imt" = `ИМТ`
)]
head(dt,4)

#### Выбор строк datatable #### 

# Для выбора строк по условию достаточно написать условие сразу после квадратных скобок.
dt2 <- dt[is_completed == TRUE & age >= 18]
head(dt2,4)
# Можно комбинировать операции выбора строк и создания новых столбцов. 
# В этом случае значение для нового столбца будет заполнено только для тех строк, 
# для которых выполняется условие.
dt <- dt[is_completed == TRUE & age >= 18, status := "Взрослые, завершившие"]
dt <- dt[is_completed == FALSE & age >= 18, status := "Взрослые, продолжающие"]
head(dt,4)

#### Сортировка datatable #### 

setorder(dt, -is_completed, age)
head(dt,4)
tail(dt,4)

#### Группировка datatable ####

dtg <- dt[
  # i: Отбираем нужные строки  
  is_completed == TRUE,                 
  # j: Считаем агрегирующие функции
  .(min_age = min(age, na.rm = TRUE),   
    mean_age = mean(age, na.rm = TRUE),
    max_age = max(age, na.rm = TRUE),
    .N  # Считаем количество
  ),
  # by: Определяем столбцы группировки
  by = list(status)         
]
head(dtg)

#### Операции в памяти с таблицами `data.table` ####

# Прочитаем файл
dt <- fread("./files/temperature.csv")
# Присвоим объект dt новой переменной
dt_copy <- dt
# Удалим столбцы 
dt[, c("patient_id","day") := NULL ]

# Проверим объект dt
head(dt,4)

# Проверим объект dt_copy
head(dt_copy,4)

#### Копирование объектов `data.table` ####

# Скопируем объект
dt_copy <- copy(dt)
# Создадим новый столбец
dt[, new_column := "A"]

# Проверим объект dt
head(dt,4)

# Проверим объект dt_copy
head(dt_copy,4)

#### Сохранение данных ####

# Буфер обмена
write.table(df, "clipboard", sep="\t", row.names=FALSE)

# Сохранение набора данных в CSV
library(readr)
write_csv2(df, "data_result_readr.csv", na = "", quote = "none") 

# Сохранение набора данных в Excel
wb <- createWorkbook()
addWorksheet(wb, "Sheet 1")
writeData(wb, "Sheet 1", df)
saveWorkbook(wb, "my_data.xlsx", overwrite = TRUE)

# Сохранение набора данных в формат R
saveRDS(df, "data.rds")
readRDS("data.rds")

# Сохранение всего рабочего пространства
save.image("my_work_space.RData")
load("my_work_space.RData")












